/*cart_create*/
#include <mpi.h>
#include <stdio.h>
int main (int argc, char *argv[]){
  int nprocs, myrank ; 
  int ndims, newprocs, newrank;
  MPI_Comm newcomm;
  int dimsize[2], periods[2], reorder;
  int i,j,coords[2],rank, direction, displ,left,right;
  MPI_Init(&argc, &argv);
  MPI_Comm_size(MPI_COMM_WORLD, &nprocs);
  MPI_Comm_rank(MPI_COMM_WORLD, &myrank);
  ndims = 2; dimsize[0] = 3; dimsize[1] = 2;
  periods[0] = 1; periods[1] = 0; reorder = 1;
  MPI_Cart_create(MPI_COMM_WORLD,ndims,dimsize,periods,reorder,
                  &newcomm);
  direction=0; displ=1;
  MPI_Cart_shift(newcomm, direction, displ, &left, &right); 
  printf("myrank (%d) : left = %d, right = %d\n", 
                                   newrank, left, right);
  MPI_Finalize();
  return 0;
} 

