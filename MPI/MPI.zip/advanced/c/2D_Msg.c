/*
	Example Name	: lab5.c
	Compile	: $ mpicc -g -o lab5 -Wall lab5.c		
	Run		: $ mpirun -np 4 -hostfile hosts lab5
*/
#include <stdio.h>
#include <math.h>
#include <mpi.h>

#define	LOCAL_ROW 5
#define	LOCAL_COL 5

#define	GLOBAL_ROW 10
#define	GLOBAL_COL 10

#define MAX_PROCS 16

int main (int argc, char *argv[])
{
	int nRank, nProcs, ROOT = 0;
	int i, j, row, col;
	int nLocalGrid[LOCAL_ROW][LOCAL_COL];
	int nGlobalGrid[GLOBAL_ROW][GLOBAL_COL];
	MPI_Status status[MAX_PROCS];
	MPI_Request req[MAX_PROCS];
	MPI_Init(&argc, &argv);		    // MPI start
	MPI_Comm_rank(MPI_COMM_WORLD, &nRank);	    // Get current processor rank id
	MPI_Comm_size(MPI_COMM_WORLD, &nProcs);   // Get number of processors
	
	// Init Local Array
	for (i = 0; i < LOCAL_ROW; i++)
		for (j = 0; j < LOCAL_COL; j++)
			nLocalGrid[i][j] = (nRank+1)*100 + i*LOCAL_COL + j + 1;
	MPI_Barrier(MPI_COMM_WORLD);
	printf("nRank : %d\n", nRank);
	printf("-------------------\n");
	for (i = 0; i < LOCAL_ROW; i++) {
		for (j = 0; j < LOCAL_COL; j++) {
			printf("%d ", nLocalGrid[i][j]);
		}
		printf("\n");
	}
	printf("-------------------\n");

	if (nRank != ROOT) {
		MPI_Isend(nLocalGrid[0], LOCAL_COL, MPI_INTEGER, ROOT, 11, MPI_COMM_WORLD, &req[0]);
		MPI_Isend(nLocalGrid[1], LOCAL_COL, MPI_INTEGER, ROOT, 12, MPI_COMM_WORLD, &req[1]);
		MPI_Isend(nLocalGrid[2], LOCAL_COL, MPI_INTEGER, ROOT, 13, MPI_COMM_WORLD, &req[2]);
		MPI_Isend(nLocalGrid[3], LOCAL_COL, MPI_INTEGER, ROOT, 14, MPI_COMM_WORLD, &req[3]);
		MPI_Isend(nLocalGrid[4], LOCAL_COL, MPI_INTEGER, ROOT, 15, MPI_COMM_WORLD, &req[4]);
		for (i = 0; i < 5; i++) 
			MPI_Wait(&req[i], &status[i]);
	}
	else {
		for (i = 0; i < LOCAL_ROW; i++)
			for (j = 0; j < LOCAL_COL; j++)
				nGlobalGrid[i][j] = nLocalGrid[i][j];

		for (i = 1; i < nProcs; i++) {
			row = i / (int)sqrt(nProcs);
			col = i % (int)sqrt(nProcs);

			MPI_Recv(&nGlobalGrid[row*LOCAL_ROW][col*LOCAL_COL], LOCAL_COL,
                             MPI_INT, i, 11, MPI_COMM_WORLD, &status[0]);
			MPI_Recv(&nGlobalGrid[row*LOCAL_ROW+1][col*LOCAL_COL], LOCAL_COL,
                             MPI_INT, i, 12, MPI_COMM_WORLD, &status[1]);
			MPI_Recv(&nGlobalGrid[row*LOCAL_ROW+2][col*LOCAL_COL], LOCAL_COL,
                             MPI_INT, i, 13, MPI_COMM_WORLD, &status[2]);
			MPI_Recv(&nGlobalGrid[row*LOCAL_ROW+3][col*LOCAL_COL], LOCAL_COL,
                             MPI_INT, i, 14, MPI_COMM_WORLD, &status[3]);
			MPI_Recv(&nGlobalGrid[row*LOCAL_ROW+4][col*LOCAL_COL], LOCAL_COL,
                             MPI_INT, i, 15, MPI_COMM_WORLD, &status[4]);
		}
		printf("nRank : %d (Total)\n", nRank);
		printf("-------------------------------------------\n");

		for (i = 0; i < GLOBAL_ROW; i++) {
			for (j = 0; j < GLOBAL_COL; j++) {
				printf("%d ", nGlobalGrid[i][j]);
				if (j == (GLOBAL_COL/2)-1)
					printf(" |  ");
			}
			
			if (i == (GLOBAL_ROW/2)-1) {
				printf("\n");
				for (j = 0; j <= GLOBAL_COL; j++) {
					printf(" -  ");
				}
			}
			printf("\n");
		}
		printf("-------------------------------------------\n");
	}

	MPI_Finalize();
	return 0;
}


