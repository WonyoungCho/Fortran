#include <stdio.h>
#include <mpi.h>
int main(int argc, char *argv[])
{
   int isend[3], irecv[3];
   int i,nprocs, myrank;
   MPI_Init(&argc, &argv);
   MPI_Comm_size(MPI_COMM_WORLD,&nprocs);
   MPI_Comm_rank(MPI_COMM_WORLD, &myrank);
   for(i=0;i<nprocs;i++){
        isend[i]=1+i+nprocs*myrank;
   }
   printf("%s(%d) : %d %d %d\n","myrank",myrank,
           isend[0],isend[1],isend[2]);
   MPI_Alltoall(isend,1,MPI_INT, irecv,1,MPI_INT,MPI_COMM_WORLD);
   printf("%s(%d) : %d %d %d\n","myrank",myrank,
          irecv[0],irecv[1],irecv[2]);
   MPI_Finalize();
   return 0;
}

